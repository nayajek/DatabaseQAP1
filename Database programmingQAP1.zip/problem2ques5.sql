SELECT c.customer_id, c.first_name, r.rental_id
FROM customer c
JOIN rental r ON c.customer_id = r.customer_id
