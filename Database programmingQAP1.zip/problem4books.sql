INSERT INTO books (title, author_id, publication_year) VALUES ('Pride and Prejudice', 1, 1813);
INSERT INTO books (title, author_id, publication_year) VALUES ('Sense and Sensibility', 1, 1811);
INSERT INTO books (title, author_id, publication_year) VALUES ('Great Expectations', 2, 1861);

SELECT * FROM books