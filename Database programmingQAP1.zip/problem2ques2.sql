SELECT title, rental_duration, rental_rate
FROM film
WHERE rental_duration > 6 AND rental_rate < 2.99;