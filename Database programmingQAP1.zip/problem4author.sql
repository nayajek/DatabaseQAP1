INSERT INTO authors (first_name, last_name) VALUES ('Jane', 'Austen');
INSERT INTO authors (first_name, last_name) VALUES ('Charles', 'Dickens');

SELECT * FROM authors