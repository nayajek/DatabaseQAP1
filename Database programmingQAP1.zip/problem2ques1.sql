SELECT first_name, last_name, email
FROM customer;