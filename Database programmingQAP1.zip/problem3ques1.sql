SELECT * FROM customer
WHERE last_name = 'Jecks'

SELECT * FROM address

INSERT INTO address (address_id, address, district, city_id, postal_code, phone, last_update)
VALUES ('606', '12 Forcados Street', 'Gander', '555', '12345', '112233445566','2024-05-14' )

INSERT INTO customer (customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active)
VALUES ('600','1','Devin','Jecks','devin.jecks@sakilacustomer.org', '606', 'true', '2024-05-14','2024-05-15', '1'),
	('601','1','Derrick','Jecks','derrick.jecks@sakilacustomer.org', '606', 'true', '2024-05-14','2024-05-15', '1'),
('602','1','Dylan','Jecks','dylan.jecks@sakilacustomer.org', '606', 'true', '2024-05-14','2024-05-15', '1'),
('603','1','Darren','Jecks','darren.jecks@sakilacustomer.org', '606', 'true', '2024-05-14','2024-05-15', '1'),
('604','1','Daniel','Jecks','daniel.jecks@sakilacustomer.org', '606', 'true', '2024-05-14','2024-05-15', '1'),
('605','1','Drake','Jecks','drake.jecks@sakilacustomer.org', '606', 'true', '2024-05-14','2024-05-15', '1')