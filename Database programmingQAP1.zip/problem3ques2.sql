UPDATE customer
SET address_id = '607'
WHERE last_name = 'Jecks';

SELECT * FROM customer
WHERE last_name ='Jecks';

INSERT INTO address (address_id, address, district, city_id, postal_code, phone, last_update)
VALUES ('607', '15 Tully Place', 'Gambo', '556', '67895','112233445566', '2024-05-15'  )